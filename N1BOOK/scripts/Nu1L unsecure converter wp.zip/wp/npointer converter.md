# 整体出题思路

1. CVE-2016-3714
2. padding oracle

# Writeup

由于题目提供了源代码, 直接开始审计

审计go代码, 首先找入口点, 然后一步一步跟着调

题目中的路由在 `helper.go`中

![npointer%20converter/Untitled.png](npointer%20converter/Untitled.png)

功能非常简单, 分别为

    /api/list     ->   列出当前用户都上传了什么文件
    /api/new      ->   新建上传请求, 检查上传文件是否合法
    /api/convert  ->   进行转换操作

在创建上传请求过程中, 程序总共进行了如下几个步骤

1. 文件名是否合法(`checkFilenameSecure`)
2. 文件类型是否合法(`checkFileTypeSecure`)
3. 即将转换过去的文件类型是否合法(`checkFileDestTypeSecure`)
4. 保存用户上传的文件(`SaveUploadedFile`)
5. 将json序列化后上传请求加密, 回传给客户端(`json.Marshal` 和 `encrypt` )

在上传请求结束后, 自动重定向到转换功能路由, 并进行了如下操作

1. 解密并反序列化json数据(`decrypt` 和 `json.Unmarshal`)
2. 检查源文件名, 目的文件名是否合法(``checkFilenameSecure` )
3. 拼接目的文件名, 转换(`generateRes`)

逐步进行审计

1. `checkFilenameSecure`

    将附件保存文件夹的根地址与可控的文件名连接, 并判断和附件保存文件夹的根地址的相对路径是否以 `'./'` 开始, 应该没什么问题

2. `checkFileTypeSecure`

    通过 `goimghdr.WhatFromReader` 库判断文件类型是否为 `"jpeg", "png", "gif", "bmp"` 之一

3. `checkFileDestTypeSecure`

    通过判断post表单中的type是否合法, 看起来也没什么问题

4. `encrypt` 

    跟到 `aes.go` 中, 发现非常明显的人为创造出来的可以被 `padding oracle` 攻击利用的漏洞

5. `decrypt` 

    同上

6. `generateRes`

    通过 `"[gopkg.in/gographics/imagick.v2/imagick](http://gopkg.in/gographics/imagick.v2/imagick)"` 库, 进行图片文件的类型转换, 发现这个库是使用的 `ImageMagick` 完成的转换过程, 使用的 `ImageMagick` 为6.x.x 版本, 

那么现在来总结一下我们的发现:

1. Padding Oracle 可以伪造任意密文
2. 伪造之后, 转换的文件类型, 文件名, 转换前的文件名均可控
3. 在网上搜索ImageMagick6漏洞

    发现了CVE-2016-3714, 漏洞的产生原因是imagemagick没过滤文件名, 直接将未经处理的文件名拼接到了要执行的命令中, 从而导致了这个漏洞.

    通过观察ubuntu默认安装的ImageMagick-6的delegates(运行 `identify -list delegate` 命令), 我们发现引发漏洞的 `%M` 这个参数依然在一堆命令中有用到 

    ![npointer%20converter/Untitled%201.png](npointer%20converter/Untitled%201.png)

    继续深入查 `/etc/ImageMagick-6/delegates.xml`时, 发现miff这个文件类型可以通过 `.show, .win`两种扩展名触发

    ![npointer%20converter/Untitled%202.png](npointer%20converter/Untitled%202.png)

    以及根据 `mpeg:encode` 可以通过 `.mp4, .mpeg` 等等文件触发

    ![npointer%20converter/Untitled%203.png](npointer%20converter/Untitled%203.png)

现在就有了整体的利用思路

首先由于%M利用的是原文件名, 所以我们先将文件名含有RCE PoC的图片上传上去, 比如我这里使用的是

    test';echo Y3AgL2ZsYWcgL2FwcC9hdHRhY2htZW50cy8x|base64 -d|sh;#'

再通过padding oracle伪造密文, 得到转换参数, 将我们想要的文件格式传进去, 我这里使用的是 `.show`这个格式

    {"filename":"test';echo Y3AgL2ZsYWcgL2FwcC9hdHRhY2htZW50cy8x|base64 -d|sh;#'","type":"show"}

padding oracle伪造密文的脚本在github上有, 我们找一个修改一下就可以直接用了. 我这里选用的库是[https://github.com/lesterpotter/AesOracle](https://github.com/lesterpotter/AesOracle)

最后在完成密文伪造后, 就可以把伪造的密文传给 `/api/convert` 去进行转换, 最终完成命令执行

完整的利用代码在: [https://gist.github.com/ManassehZhou/09a6277810141059502dc9631833cdad](https://gist.github.com/ManassehZhou/09a6277810141059502dc9631833cdad)
